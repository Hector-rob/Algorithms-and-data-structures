//Act 4.1 - Grafo: sus representaciones y sus recorridos
//Héctor Robles Villarreal A01634105
//Sábado 13 de noviembre de 2021

#include "Grafo.h"
using namespace std;

int main(){
    Graph::loadGraph("grafo.txt");
	return 0;
}